package Main

import entities.Booking.BookingImpl
import entities.History.VehicleHistory
import entities.ParkingLot.{Car, ParkingLotImpl, ParkingLotProvider, RateCatalogue, Scooter}

object Main {
  def main(args: Array[String]): Unit = {
    val parkingLotAdminInterface = ParkingLotProvider.getAdminInterface()
    //val parkingLot = new ParkingLotImpl(10)
    parkingLotAdminInterface.build(Car,10).build(Scooter,20).build(RateCatalogue(Car,Range(0,2)),10).build(
      RateCatalogue(Scooter,Range(0,2)),20)
    println(parkingLotAdminInterface)

//   println(BookingImpl.vehicleEntry(1,Car))
//    println(BookingImpl.vehicleEntry(2,Car))
//    println(BookingImpl.vehicleEntry(2,Car))
//    println(BookingImpl.vehicleExit(1))
//
//    println(VehicleHistory.getHistory(1,0,0))

  }
}
