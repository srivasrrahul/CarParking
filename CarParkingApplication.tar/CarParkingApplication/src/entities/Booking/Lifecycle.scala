package entities.Booking

import entities.ParkingLot.{ParkingLotId, VehicleType}

trait BookingLifecycle

class Parking(val bookingID : Int,val vehicleID : Int, val vehicleType: VehicleType,val parkingLotId: ParkingLotId,val time : Int) extends BookingLifecycle

class ParkingExit(val bookingID : Int,val amount : Int) extends BookingLifecycle