package entities.Booking

import entities.History.VehicleHistory
import entities.ParkingLot.{Occupied, ParkingLotId, ParkingLotProvider, RateCatalogue, Unoccupied, VehicleType}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

object BookingImpl {
  var time = 0
  def getNewID() : Int = {
    time = time+1
    time
  }
  private val m_BookingHistory = new ListBuffer[BookingLifecycle] //Append only
  private val m_BookingID = new mutable.HashMap[Int,Parking]() //booking-id vs Parking


  def vehicleEntry(vehicleId : Int,vehicleType: VehicleType) : Option[Int] = {
    val parkingLot = ParkingLotProvider.getUserInterface()
    val lst = parkingLot.listAllStatus(vehicleType)
    var found = false
    var freeLot : ParkingLotId = null
    for (parkingLot <- lst if found == false) {
      parkingLot._2 match {
        case Occupied => {
          //None
        }
        case Unoccupied => {
          found = true
          freeLot = parkingLot._1
        }
      }
    }

    if (found == true) {
      val bookingId = getNewID()
      val parking = new Parking(bookingId,vehicleId,vehicleType,freeLot,System.currentTimeMillis().toInt)
      m_BookingHistory.append(parking)
      m_BookingID += ((bookingId,parking))
      VehicleHistory.newParking(parking)
      Some(bookingId)
    }else {
      None
    }
  }

  def vehicleExit(bookingID : Int) : Unit = {
    val newId = getNewID()
    val parkingLot = ParkingLotProvider.getUserInterface()
    val parking = m_BookingID.get(bookingID).get

    val rate = parkingLot.getRate(new RateCatalogue(parking.vehicleType,Range(System.currentTimeMillis().toInt,parking.time)))

    val amount = rate.get //assume succes for now
    val exitEvent = new ParkingExit(bookingID,amount)

    VehicleHistory.newExit(parking.vehicleID,exitEvent)
    m_BookingHistory.append(exitEvent)
  }
}
