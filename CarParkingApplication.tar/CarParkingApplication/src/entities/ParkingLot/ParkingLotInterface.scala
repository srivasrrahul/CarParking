package entities.ParkingLot

trait VehicleType

object Car extends VehicleType
object Scooter extends VehicleType

case class RateCatalogue(vehicleType: VehicleType,duration: Range)
case class ParkingLotId(vehicleType: VehicleType,id : Int)

trait ParkingStatus
object Occupied extends ParkingStatus
object Unoccupied extends ParkingStatus

trait ParkingLotInterface {
  def getId() : Int
//  def getCount(vehicleType: VehicleType) : Option[Int]
////  def incCount(vehicleType: VehicleType) : Unit
////  def decCount(vehicleType: VehicleType) : Unit
  def getRate(rateCatalogue: RateCatalogue) : Option[Int]
  def listAllStatus(vehicleType : VehicleType) : List[(ParkingLotId,ParkingStatus)]
  def setStatus(vehicleType: VehicleType,parkingLotId: ParkingLotId,status: ParkingStatus) : Unit
}

trait ParkingLotAdminInterface {
  def build(vehicleType: VehicleType,count : Int) : ParkingLotAdminInterface
  def build(rate: RateCatalogue,amount : Int) : ParkingLotAdminInterface
}
