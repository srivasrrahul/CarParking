package entities.ParkingLot

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

class ParkingLotImpl(val m_Id : Int) extends ParkingLotInterface with ParkingLotAdminInterface {
  override def getId(): Int = {
    m_Id
  }

  private val m_Counts = new mutable.HashMap[VehicleType,Int]()
  private val m_Rates = new mutable.HashMap[RateCatalogue,Int]()

//  override def getCount(vehicleType: VehicleType): Option[Int] = {
//    m_Counts.get(vehicleType)
//  }
//
//  override def incCount(vehicleType: VehicleType): Unit = {
//    val existingCount = m_Counts.getOrElse(vehicleType,1)
//    m_Counts += ((vehicleType,existingCount-1))
//  }

//  override def decCount(vehicleType: VehicleType): Unit = {
//    val existingCount = m_Counts.getOrElse(vehicleType,1)
//    m_Counts += ((vehicleType,existingCount-1))
//  }

  override def build(vehicleType: VehicleType, count: Int): ParkingLotAdminInterface = {
    m_Counts += ((vehicleType,count))
    m_VehicleAllSlots += ((vehicleType,new mutable.HashMap[ParkingLotId,ParkingStatus]()))
    val map = m_VehicleAllSlots.get(vehicleType).get
    for (j <- 0 to count-1) {
      map += ((ParkingLotId(vehicleType,j),Unoccupied))
    }
    this
  }

  override def build(rate: RateCatalogue,amount : Int): ParkingLotAdminInterface = {
    m_Rates += ((rate,amount))
    this
  }

  override def getRate(rateCatalogue: RateCatalogue): Option[Int] = {
    m_Rates.get(rateCatalogue) match {
      case None => {
        Some(100) //default value hardcoded for test
      }
      case Some(_) => {
        m_Rates.get(rateCatalogue)
      }
    }
  }


  private val m_VehicleAllSlots = new mutable.HashMap[VehicleType,mutable.HashMap[ParkingLotId,ParkingStatus]]
  override def listAllStatus(vehicleType: VehicleType): List[(ParkingLotId,ParkingStatus)] = {
    m_VehicleAllSlots.get(vehicleType).get.toList
  }


  override def setStatus(vehicleType: VehicleType, parkingLotId: ParkingLotId, status: ParkingStatus): Unit = {
    if (m_VehicleAllSlots.get(vehicleType).contains(parkingLotId)) {
      m_VehicleAllSlots.get(vehicleType).get += ((parkingLotId,status))
    }
  }

  override def toString = s"ParkingLotImpl($m_Counts, $m_Rates, $m_Id)"


}
