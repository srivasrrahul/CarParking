package entities.ParkingLot

object ParkingLotProvider {
  private val m_ParkingLot = new ParkingLotImpl(10) //hardcode for now useful in multi-tenancy
  def getUserInterface() : ParkingLotInterface = {
    m_ParkingLot
  }

  def getAdminInterface() : ParkingLotAdminInterface = {
    m_ParkingLot
  }
}
