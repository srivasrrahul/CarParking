package entities.History

import entities.Booking.{Parking, ParkingExit}

trait VehicleHistoryInterface {
  def onParking(parking: Parking) : Unit
  def onExit(vehicelId : Int,exit : ParkingExit) : Unit
}
