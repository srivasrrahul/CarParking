package entities.History

import entities.Booking.{BookingLifecycle, Parking, ParkingExit}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

object VehicleHistory {
  private val m_History = new mutable.HashMap[Int,ListBuffer[BookingLifecycle]]()

  def newParking(parking : Parking) : Unit = {
    val buffer = m_History.getOrElseUpdate(parking.vehicleID,new ListBuffer[BookingLifecycle])
    buffer.append(parking)
  }

  def newExit(vehilceId : Int,parkingExit: ParkingExit) : Unit = {
    val buffer = m_History.getOrElseUpdate(vehilceId,new ListBuffer[BookingLifecycle])
    buffer.append(parkingExit)
  }

  def getHistory(vehicleId: Int,startTime : Int,endTime : Int) : List[BookingLifecycle] = {
    //ignore time
    m_History.getOrElse(vehicleId,new ListBuffer[BookingLifecycle]).toList
    //paginate it later
  }
}
